//
//  ViewController.m
//  RodarSensor
//
//  Created by n/a on 19.09.17.
//  Copyright © 2017 n/a. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end
@interface ViewController ()
- (void) sendDataToHost: (CGFloat)total atLocation: (CLLocationCoordinate2D) location;
@end


#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>


@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    currentMaxAccelX = 0;
    currentMaxAccelY = 0;
    currentMaxAccelZ = 0;
    
    currentMaxRotX = 0;
    currentMaxRotY = 0;
    currentMaxRotZ = 0;
    
    self.motionManager = [[CMMotionManager alloc] init];
    self.motionManager.accelerometerUpdateInterval = .2;
    self.motionManager.gyroUpdateInterval = .2;
    
    [self.motionManager startAccelerometerUpdatesToQueue:[NSOperationQueue currentQueue]
                                             withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) {
                                                 [self outputAccelertionData:accelerometerData.acceleration];
                                                 if(error){
                                                     
                                                     NSLog(@"%@", error);
                                                 }
                                             }];
    
    [self.motionManager startGyroUpdatesToQueue:[NSOperationQueue currentQueue]
                                    withHandler:^(CMGyroData *gyroData, NSError *error) {
                                        [self outputRotationData:gyroData.rotationRate];
                                    }];
    
    
    
}

-(void)outputAccelertionData:(CMAcceleration)acceleration
{
    
    if(fabs(acceleration.x) > fabs(currentMaxAccelX))
    {
        currentMaxAccelX = acceleration.x;
    }
    if(fabs(acceleration.y) > fabs(currentMaxAccelY))
    {
        currentMaxAccelY = acceleration.y;
    }
    if(fabs(acceleration.z) > fabs(currentMaxAccelZ))
    {
        currentMaxAccelZ = acceleration.z;
    }
    
    double ax = acceleration.x;
    double ay = acceleration.y;
    double az = acceleration.z;
    double total = sqrt(ax*ax + ay*ay + az*az);

    
    double totalMax = sqrt(currentMaxAccelX*currentMaxAccelX + currentMaxAccelY*currentMaxAccelY + currentMaxAccelZ*currentMaxAccelZ);
    
    NSString *message = @"- - - - - -";

    if(totalMax > total)
        message = @"+ + + + + +";

    if(2.0 < total)
    {
        CLLocationCoordinate2D loc = CLLocationCoordinate2DMake(50.01,7.01);
        [self sendDataToHost: total atLocation: loc];
        self.totalText.text = message;

    }
    else
        self.totalText.text = [NSString stringWithFormat:@" %.2f",total];
    
    
}
-(void)outputRotationData:(CMRotationRate)rotation
{
    
    self.rotX.text = [NSString stringWithFormat:@" %.2fr/s",rotation.x];
    if(fabs(rotation.x)> fabs(currentMaxRotX))
    {
        currentMaxRotX = rotation.x;
    }
    self.rotY.text = [NSString stringWithFormat:@" %.2fr/s",rotation.y];
    if(fabs(rotation.y) > fabs(currentMaxRotY))
    {
        currentMaxRotY = rotation.y;
    }
    self.rotZ.text = [NSString stringWithFormat:@" %.2fr/s",rotation.z];
    if(fabs(rotation.z) > fabs(currentMaxRotZ))
    {
        currentMaxRotZ = rotation.z;
    }
    
    self.maxRotX.text = [NSString stringWithFormat:@" %.2f",currentMaxRotX];
    self.maxRotY.text = [NSString stringWithFormat:@" %.2f",currentMaxRotY];
    self.maxRotZ.text = [NSString stringWithFormat:@" %.2f",currentMaxRotZ];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)resetMaxValues:(id)sender {
    
    currentMaxAccelX = 0;
    currentMaxAccelY = 0;
    currentMaxAccelZ = 0;
    
    currentMaxRotX = 0;
    currentMaxRotY = 0;
    currentMaxRotZ = 0;
    
}

- (void) sendDataToHost: (CGFloat)total atLocation: (CLLocationCoordinate2D) location
{
    // Create the URLSession on the default configuration
    NSURLSessionConfiguration *defaultSessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration:defaultSessionConfiguration];
    
    // Setup the request with URL
    NSURL *url = [NSURL URLWithString:@"https://dthack17.de/api/sensors"];
    NSLog(@"%@", url.absoluteString);
    // Convert POST string parameters to data using UTF8 Encoding
//    NSString *postParams = [NSString stringWithFormat: @"%f, %f, %f", total, location.latitude, location.longitude];
  //  NSData *postData = [postParams dataUsingEncoding:NSUTF8StringEncoding];

    NSString *accelStr = [NSString stringWithFormat:@"%.3f", total];
    NSString *latStr = [NSString stringWithFormat:@"%.3f", location.latitude];
    NSString *lonStr = [NSString stringWithFormat:@"%.3f", location.longitude];

    NSDictionary *dict = @{ @"acceleration" : accelStr,
                            @"latitude" : latStr,
                            @"longitude" :lonStr};

    NSError *jsonSerializationError = nil;
//    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:&jsonSerializationError];

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&jsonSerializationError];
    if (nil != jsonSerializationError)
    {
        NSLog(@"%@; %@",jsonSerializationError.description, jsonSerializationError.debugDescription);
    }
    else{
        NSString *postLength = [NSString stringWithFormat:@"%ld", jsonData.length];
        
//        NSData *aData = [@"Das ist ein kleiner Test" dataUsingEncoding:NSUTF8StringEncoding];

        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:30.0];
        [urlRequest setValue:@"application/json" forHTTPHeaderField:@"Content­-Type"];
        [urlRequest setHTTPBody: jsonData];
        [urlRequest setHTTPMethod:@"POST"];
        
        
        [urlRequest setValue:postLength forHTTPHeaderField:@"Content-Length"];
        
        //    [urlRequest setValue:@"application/json" forHTTPHeaderField: @"Accept"];
        
        NSLog(@"Request body %@", [[NSString alloc] initWithData:[urlRequest HTTPBody] encoding:NSUTF8StringEncoding]);
        // Create dataTask
        
        NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            NSString *returnString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            // Handle your response here
            NSLog(@"response:  %@", returnString);
            
        }];
        [dataTask resume];
    }

    // Fire the request
}

@end
