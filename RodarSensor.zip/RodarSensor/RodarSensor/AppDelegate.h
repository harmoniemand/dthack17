//
//  AppDelegate.h
//  RodarSensor
//
//  Created by n/a on 19.09.17.
//  Copyright © 2017 n/a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

