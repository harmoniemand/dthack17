//
//  ViewController.h
//  RodarSensor
//
//  Created by n/a on 19.09.17.
//  Copyright © 2017 n/a. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>
#import <CoreLocation/CoreLocation.h>


CGFloat currentMaxAccelX;
CGFloat currentMaxAccelY;
CGFloat currentMaxAccelZ;
CGFloat currentMaxRotX;
CGFloat currentMaxRotY;
CGFloat currentMaxRotZ;

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *rotX;
@property (strong, nonatomic) IBOutlet UILabel *rotY;
@property (strong, nonatomic) IBOutlet UILabel *rotZ;

@property (strong, nonatomic) IBOutlet UILabel *maxRotX;
@property (strong, nonatomic) IBOutlet UILabel *maxRotY;
@property (strong, nonatomic) IBOutlet UILabel *maxRotZ;

@property (strong, nonatomic) IBOutlet UILabel *totalText;

- (IBAction)resetMaxValues:(id)sender;

@property (strong, nonatomic) CMMotionManager *motionManager;

@end

